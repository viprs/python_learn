#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest


class TestMountain(unittest.TestCase):

    def setUp(self):
        pass

    def test_it_gets_test_results(self):
        pass

